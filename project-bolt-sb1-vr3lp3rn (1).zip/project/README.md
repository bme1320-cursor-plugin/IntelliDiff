# IntelliDiff - Git Diff with AI Analysis

IntelliDiff is a VS Code extension that enhances Git diff viewing capabilities by adding AI-powered code change analysis. This extension helps developers understand code changes more effectively by providing context, explanations, and insights about modifications between Git references.

## Features

- **Advanced Git Comparison**: Compare any two Git references (branches, commits, tags, working tree)
- **Comprehensive File Diff View**: Clearly visualize changes with file grouping by status
- **AI-Powered Change Analysis**: Get semantic explanations of what changed and why
- **Interactive Q&A**: Ask questions about specific changes and get intelligent answers
- **Binary File Support**: Basic binary file comparison information
- **Change Impact Assessment**: Understand how changes affect your codebase
- **Issue Detection**: Automatically identify potential issues in code changes
- **Code Improvement Suggestions**: Receive context-aware recommendations

## Requirements

- Visual Studio Code 1.60.0 or higher
- Git installed and available in your PATH
- Python 3.6+ for AI analysis capabilities

## Extension Settings

This extension contributes the following settings:

* `intellidiff.pythonPath`: Path to Python executable for AI analysis
* `intellidiff.enableDeepAnalysis`: Enable more detailed AI analysis (may be slower)

## Getting Started

1. Install the extension
2. Open a Git repository in VS Code
3. Use the command palette (`Ctrl+Shift+P`) and select "IntelliDiff: Compare Git Versions"
4. Select the base and compare references
5. Browse the changed files and click on one to analyze

## How to Use

### Comparing Git Versions

1. Run the "IntelliDiff: Compare Git Versions" command
2. Select base reference (e.g., a branch, commit, or tag)
3. Select compare reference
4. View the list of changed files in the IntelliDiff Explorer view

### Analyzing Changes

1. Click on a file in the IntelliDiff Explorer view
2. View the AI analysis in the Analysis panel
3. Navigate through the changes
4. Click on specific changes to navigate to them in the editor

### Asking Questions

1. Open the Analysis panel
2. Type your question in the input box (e.g., "Why was this code changed?")
3. View the AI-generated answer

## Known Issues

- Analysis of very large files may be slow
- Python must be installed for AI capabilities to work
- Currently limited binary file support

## Release Notes

### 0.1.0

- Initial release
- Basic Git diff comparison
- AI-powered code change analysis
- Interactive Q&A
- Binary file basic support

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This extension is licensed under the [MIT License](LICENSE.md).